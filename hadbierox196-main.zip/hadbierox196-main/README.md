simple chat bot
